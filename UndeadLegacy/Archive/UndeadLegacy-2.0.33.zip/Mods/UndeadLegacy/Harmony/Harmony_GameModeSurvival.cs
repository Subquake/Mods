using DMT;
using Harmony;
using System;
using System.Reflection;
using UnityEngine;

[HarmonyPatch(typeof(GameModeSurvival))]
[HarmonyPatch("GetSupportedGamePrefsInfo")]
public class SQX_GameModeSurvival : IHarmony {
    public void Start(){
        Debug.Log("[Harmony] Loading Patch: " + this.GetType().ToString());
        var harmony = HarmonyInstance.Create(GetType().ToString());
        harmony.PatchAll(Assembly.GetExecutingAssembly());
    }
    static GameMode.ModeGamePref[] Postfix(GameMode.ModeGamePref[] __result){
        global::GameMode.ModeGamePref[] properties;
        properties = new GameMode.ModeGamePref[]{
			    new GameMode.ModeGamePref(EnumGamePrefs.ItemWeightMultiplier, GamePrefs.EnumType.Int, 100),
                new GameMode.ModeGamePref(EnumGamePrefs.BlockWeightMultiplier, GamePrefs.EnumType.Int, 100),
                new GameMode.ModeGamePref(EnumGamePrefs.FoodBurnRateMultiplier, GamePrefs.EnumType.Int, 100),
                new GameMode.ModeGamePref(EnumGamePrefs.WaterBurnRateMultiplier, GamePrefs.EnumType.Int, 100),
                new GameMode.ModeGamePref(EnumGamePrefs.RecipeFilter, GamePrefs.EnumType.Int, 0),
                new GameMode.ModeGamePref(EnumGamePrefs.DroppedLootDecay, GamePrefs.EnumType.Int, 30)
            };
        int array1OriginalLength = __result.Length;
        Array.Resize<GameMode.ModeGamePref>(ref __result, array1OriginalLength + properties.Length);
        Array.Copy(properties, 0, __result, array1OriginalLength, properties.Length);
        return __result;
    }
}