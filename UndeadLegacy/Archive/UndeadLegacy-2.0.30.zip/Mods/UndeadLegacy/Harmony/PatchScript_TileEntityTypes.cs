using DMT;
using Harmony;
using System;
using System.Reflection;
using UnityEngine;

[HarmonyPatch(typeof(TileEntity))]
[HarmonyPatch("Instantiate")]
[HarmonyPatch(new Type[] { typeof(TileEntityType), typeof(Chunk) })]

public class SQX_TileEntityTypePatch : IHarmony {
    public void Start(){
        Debug.Log("[Harmony] Loading Patch: " + this.GetType().ToString());
        var harmony = HarmonyInstance.Create(GetType().ToString());
        harmony.PatchAll(Assembly.GetExecutingAssembly());
    }

    static TileEntity Postfix(TileEntity __result, TileEntityType type, Chunk _chunk){
        if(__result == null) {
            switch (type){
                case global::TileEntityType.StorageTank:
                    return new global::TileEntityStorageTank(_chunk);
            }
            Log.Warning("Tile Entity has unknown type: " + type.ToStringCached<global::TileEntityType>());
        }
        return __result;
    }

    //SDX patcher in harmony:
    // Meta in ItemValue is an int, but when writen it gets converted over to a ushort, and re-read as an int. This could be due to refactoring of base code,
    // since none of these calls need to be ushort, change the ushort to just cast as an int.
    /*
    [HarmonyPatch(typeof(ItemValue))]
    [HarmonyPatch("Write")]
    public class SphereII_ItemValue_Write
    {
        static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
        {
            // Grab all the instructions
            var codes = new List<CodeInstruction>(instructions);

            for (int i = 0; i < codes.Count; i++)
            {
                if (codes[i].opcode == OpCodes.Conv_U2)
                    codes[i].opcode = OpCodes.Conv_I;
            }

            return codes.AsEnumerable();
        }
    }
    */
}